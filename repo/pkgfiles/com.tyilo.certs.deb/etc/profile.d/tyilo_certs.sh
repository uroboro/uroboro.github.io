# Set git
git config --global http.sslCAInfo /etc/ssl/certs/all_certs.pem &> /dev/null
