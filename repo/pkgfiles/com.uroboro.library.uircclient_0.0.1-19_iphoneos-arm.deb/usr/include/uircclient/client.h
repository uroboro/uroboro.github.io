#ifndef CLIENT_H
#define CLIENT_H

#include <stdbool.h>

#include "socket.h"
#include "thread.h"
#include "structures.h"
#include "message.h"

typedef struct Client {
	Username username;
	Server server;

	Socket *socket;
	Thread *inputThread;
	Thread *outputThread;

	bool loggedIn;

	bool (*init)(struct Client *, char *host, int port, char *password, char *nick, char *user);

	bool (*connect)(struct Client *);
	bool (*disconnect)(struct Client *);

	bool (*login)(struct Client *);

	bool (*send)(struct Client *, char *data);
	bool (*sendWithFormat)(struct Client *, char *format, ...);

	bool (*receive)(struct Client *);

	bool (*hook)(struct Client *, char *command, void *(*function)(void *, Message *), void *context);
} Client;

Client *ClientNew();
void ClientDelete();

#endif
