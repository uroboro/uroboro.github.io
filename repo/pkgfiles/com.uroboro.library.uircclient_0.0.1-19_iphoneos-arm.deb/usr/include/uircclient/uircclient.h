#ifndef UIRCCLIENT_H
#define UIRCCLIENT_H

#include "cobject.h"
#include "functions.h"
#include "socket.h"
#include "thread.h"
#include "structures.h"
#include "message.h"
#include "reply.h"
#include "handler.h"
#include "client.h"

#endif /* UIRCCLIENT_H */