#ifndef COBJECT_H
#define COBJECT_H

#include <stdlib.h>

#define CO_New(T, s)		(T *)calloc(s, sizeof(T))
#define CO_Resize(v, T, s)	(T *)realloc(v, (s) * sizeof(T))
#define CO_Free(v)			free(v)

#define CO_Call(obj, f, ...)	({ __typeof(obj) o = obj; o->f ? o->f(o, ##__VA_ARGS__) : 0; })
#if 0
#define X(a,b) X_(a,b)
#define X_(a,b) a ## b
#define CO_MakeCall(a, ...) (a, ##__VA_ARGS__)
#define CO_Call(o, f, ...)	({ __typeof(o) obj = o; obj->f ? obj->f CO_MakeCall(obj, __VA_ARGS__) : 0; })
#endif

#endif /* COBJECT_H */
