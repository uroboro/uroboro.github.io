#ifndef SOCKET_H
#define SOCKET_H

#include <stdbool.h>

typedef struct Socket {
	int socketId;
	bool connected;

	bool (*connect)(struct Socket *, char const *host, int port);
	bool (*disconnect)(struct Socket *);

	bool (*send)(struct Socket *, char const *data);
	bool (*receive)(struct Socket *, char **buffer);

} Socket;

Socket *SocketNew();
void SocketDelete(Socket *);

#endif /* SOCKET_H */
