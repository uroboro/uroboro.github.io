#ifndef STRUCTURES_H
#define STRUCTURES_H

typedef struct Username {
	char *nickname;
	char *username;
	char *hostname;
} Username;

typedef struct Server {
	char *servername;
	char *hostname;
	int port;
	char *password;
} Server;

#endif /* STRUCTURES_H */
