#ifndef FUNCTIONS_H
#define FUNCTIONS_H

// Functions on top of strtok_r but returning a NULL-terminated allocated array of C strings
char **strsplit(const char *string, const char *delim);

void strsplitfree(char **v);

#endif /* FUNCTIONS_H */