#ifndef _CPP_H_
#define _CPP_H_

// source:http://jhnet.co.uk/articles/cpp_magic

#define CPP_MAGIC_FIRST(a, ...) a
#define CPP_MAGIC_SECOND(a, b, ...) b

#define CPP_MAGIC_EVAL(...)  CPP_MAGIC_EVALc(__VA_ARGS__)

#define CPP_MAGIC_EVALh(...) CPP_MAGIC_EVALg(CPP_MAGIC_EVALg(__VA_ARGS__))
#define CPP_MAGIC_EVALg(...) CPP_MAGIC_EVALf(CPP_MAGIC_EVALf(__VA_ARGS__))
#define CPP_MAGIC_EVALf(...) CPP_MAGIC_EVALe(CPP_MAGIC_EVALe(__VA_ARGS__))
#define CPP_MAGIC_EVALe(...) CPP_MAGIC_EVALd(CPP_MAGIC_EVALd(__VA_ARGS__))
#define CPP_MAGIC_EVALd(...) CPP_MAGIC_EVALc(CPP_MAGIC_EVALc(__VA_ARGS__))
#define CPP_MAGIC_EVALc(...) CPP_MAGIC_EVALb(CPP_MAGIC_EVALb(__VA_ARGS__))
#define CPP_MAGIC_EVALb(...) CPP_MAGIC_EVALa(CPP_MAGIC_EVALa(__VA_ARGS__))
#define CPP_MAGIC_EVALa(...) CPP_MAGIC_EVAL9(CPP_MAGIC_EVAL9(__VA_ARGS__))
#define CPP_MAGIC_EVAL9(...) CPP_MAGIC_EVAL8(CPP_MAGIC_EVAL8(__VA_ARGS__))
#define CPP_MAGIC_EVAL8(...) CPP_MAGIC_EVAL7(CPP_MAGIC_EVAL7(__VA_ARGS__))
#define CPP_MAGIC_EVAL7(...) CPP_MAGIC_EVAL6(CPP_MAGIC_EVAL6(__VA_ARGS__))
#define CPP_MAGIC_EVAL6(...) CPP_MAGIC_EVAL5(CPP_MAGIC_EVAL5(__VA_ARGS__))
#define CPP_MAGIC_EVAL5(...) CPP_MAGIC_EVAL4(CPP_MAGIC_EVAL4(__VA_ARGS__))
#define CPP_MAGIC_EVAL4(...) CPP_MAGIC_EVAL3(CPP_MAGIC_EVAL3(__VA_ARGS__))
#define CPP_MAGIC_EVAL3(...) CPP_MAGIC_EVAL2(CPP_MAGIC_EVAL2(__VA_ARGS__))
#define CPP_MAGIC_EVAL2(...) CPP_MAGIC_EVAL1(CPP_MAGIC_EVAL1(__VA_ARGS__))
#define CPP_MAGIC_EVAL1(...) __VA_ARGS__

#define CPP_MAGIC_PASS(...) __VA_ARGS__
#define CPP_MAGIC_EMPTY()
#define CPP_MAGIC_COMMA() ,
#define CPP_MAGIC_PLUS() +
#define CPP_MAGIC_ZERO() 0
#define CPP_MAGIC_ONE() 1

#define CPP_MAGIC_DEFER1(m) m CPP_MAGIC_EMPTY()
#define CPP_MAGIC_DEFER2(m) m CPP_MAGIC_EMPTY CPP_MAGIC_EMPTY()()

#define CPP_MAGIC_IS_PROBE(...) CPP_MAGIC_SECOND(__VA_ARGS__, 0)
#define CPP_MAGIC_PROBE() ~, 1

#define CPP_MAGIC_CAT(a,b) a ## b

#define CPP_MAGIC_NOT(x) CPP_MAGIC_IS_PROBE(CPP_MAGIC_CAT(CPP_MAGIC_NOT_, x))
#define CPP_MAGIC_NOT_0 CPP_MAGIC_PROBE()

#define CPP_MAGIC_BOOL(x) CPP_MAGIC_NOT(CPP_MAGIC_NOT(x))

#define CPP_MAGIC_IF_ELSE(condition) CPP_MAGIC__IF_ELSE(CPP_MAGIC_BOOL(condition))
#define CPP_MAGIC__IF_ELSE(condition) CPP_MAGIC_CAT(CPP_MAGIC_IF_, condition)

#define CPP_MAGIC_IF_1(...) __VA_ARGS__ CPP_MAGIC_IF_1_ELSE
#define CPP_MAGIC_IF_0(...)             CPP_MAGIC_IF_0_ELSE

#define CPP_MAGIC_IF_1_ELSE(...)
#define CPP_MAGIC_IF_0_ELSE(...) __VA_ARGS__

#define CPP_MAGIC_HAS_ARGS(...) CPP_MAGIC_BOOL(CPP_MAGIC_FIRST(CPP_MAGIC_END_OF_ARGUMENTS_ __VA_ARGS__)())
#define CPP_MAGIC_END_OF_ARGUMENTS_() 0

#define CPP_MAGIC_MAP(m, sep, first, ...)                       \
  m(first)                                                      \
  CPP_MAGIC_IF_ELSE(CPP_MAGIC_HAS_ARGS(__VA_ARGS__))(           \
    sep() CPP_MAGIC_DEFER2(CPP_MAGIC__MAP)()(m, sep, __VA_ARGS__)    \
  )()
#define CPP_MAGIC__MAP() CPP_MAGIC_MAP

#define CPP_MAGIC_MAP_PAIR(m, sep, first, second, ...)                       \
  m(first, second)                                                      \
  CPP_MAGIC_IF_ELSE(CPP_MAGIC_HAS_ARGS(__VA_ARGS__))(           \
    sep() CPP_MAGIC_DEFER2(CPP_MAGIC__MAP_PAIR)()(m, sep, __VA_ARGS__)    \
  )()
#define CPP_MAGIC__MAP_PAIR() CPP_MAGIC_MAP_PAIR

#define MAP(...) CPP_MAGIC_EVAL(CPP_MAGIC_MAP(__VA_ARGS__))
#define MAP_PAIR(...) CPP_MAGIC_EVAL(CPP_MAGIC_MAP_PAIR(__VA_ARGS__))
#define ENUM(m, ...) MAP(m, CPP_MAGIC_COMMA, ##__VA_ARGS__)
#define ENUM_PAIR(m, ...) MAP_PAIR(m, CPP_MAGIC_COMMA, ##__VA_ARGS__)

#define ID(x)         x
#define ID_PAIR(x, y) x y
#define STR(x)        # x

#endif /* _CPP_H_ */
