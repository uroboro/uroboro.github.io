#ifndef THREAD_H
#define THREAD_H

#include <stdbool.h>

#ifdef _WIN32
#include <process.h>
typedef void ThreadReturn;
typedef int ThreadId;
#else
#include <pthread.h>
typedef void* ThreadReturn;
typedef pthread_t ThreadId;
#endif

typedef ThreadReturn (*ThreadFunction)(void *);

typedef struct Thread {
	ThreadId threadId;
	bool (*start)(struct Thread *, ThreadFunction callback, void *context);
	bool (*stop)(struct Thread *);
} Thread;

Thread *ThreadNew();
void ThreadDelete(Thread *);

#endif /* THREAD_H */
