#ifndef MESSAGE_H
#define MESSAGE_H

#include "structures.h"

typedef struct Message {
	char *servername;
	Username username;

	char *command;
	char **parameters;

	void (*setServername)(struct Message *, const char *string);
	char *(*getServername)(struct Message *);

	void (*setNickname)(struct Message *, const char *string);
	char *(*getNickname)(struct Message *);

	void (*setUsername)(struct Message *, const char *string);
	char *(*getUsername)(struct Message *);

	void (*setHostname)(struct Message *, const char *string);
	char *(*getHostname)(struct Message *);

	void (*setCommand)(struct Message *, const char *string);
	char *(*getCommand)(struct Message *);

	void (*setParameters)(struct Message *, char * const *parameters);
	char **(*getParameters)(struct Message *);

	void (*parseString)(struct Message *, const char *string);
} Message;

Message *MessageNew();
void MessageDelete(Message *);

#endif /* MESSAGE_H */